package com.badlogic.angrybirds;

import com.badlogic.gdx.graphics.Texture;

public class Block extends GameObject {
    public Block(Texture texture, float x, float y) {
        super(texture, x, y);
    }
}
